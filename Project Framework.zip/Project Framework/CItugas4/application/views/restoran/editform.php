<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>



<?php $this->load->view('template/header'); ?>
<title>Tabel</title>

<body>

    <div id="wrapper">

        <?php $this->load->view('template/navbar') ?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Update Data</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Ubah data
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form  method="post" action="<?php echo base_url(); ?>restoran/UpdateForm" role="form">

                                        <div class="form-group">
                                            <h5>Kode</h5>
                                            <input type="text" class="form form-control" name="kode" id="" value="<?= $restoran['kode']; ?>">
                                            <div class="form-text text-danger"><?= form_error('kode'); ?></div>
                                        </div>

                                        <div class="form-group">
                                            <h5>Nama</h5>
                                            <input type="text" class="form form-control" name="nama" value="<?= $restoran['nama']; ?>">
                                            <div class="form-text text-danger"><?= form_error('nama'); ?></div>
                                        </div>

                                        <div class="form-group">
                                            <h5>Kategori</h5>
                                            <?php
                                            $drop = array(
                                                'name'          => 'kategori',
                                                'id'            => 'kategori',
                                                'class'            => 'form-control'
                                            );


                                            foreach ($query->result_array() as $row) {
                                                $kategori[$row['id_kategori']] = $row['nama_kategori'];
                                            }

                                            /*$kategori = array(
                                                'MIN'         => 'Minuman',
                                                'MAK'           => 'Makanan',
                                                'LAIN'         => 'Lainnya'
                                        );
                                        */
                                            $val = set_value($restoran['kategori']);
                                            echo form_dropdown('kategori', $kategori, $val, $drop);
                                            ?>
                                        </div>

                                        <div class="form-group">
                                            <h5>Harga</h5>
                                            <input class="form form-control" type="number" name="harga" value="<?= $restoran['harga']; ?>" />
                                            <div class="form-text text-danger"><?= form_error('harga'); ?></div>
                                        </div>

                                        <div class="form-group">
                                            <h5>Status</h5>
                                            <input class="form-check-input" type="radio" name="status" value="Tersedia" <?php
                                                                                                                                                echo ($restoran['status']) == 'Tersedia' ? 'checked' : '';
                                                                                                                                                 ?> />Tersedia<br>
                                            <input class="form-check-input" type="radio" name="status" value="Tidak Tersedia" <?php
                                                                                                                                         echo ($restoran['status']) == 'Tidak Tersedia' ? 'checked' : '';
                                                                                                                                            ?> />Tidak Tersedia<br>
                                        </div>

                                        <div class="form-group">
                                            <h5>Deskripsi</h5>
                                            <textarea class="form form-control" id="deskripsi" name="deskripsi" rows="4" cols="50"><?= $restoran['deskripsi'];  ?>  
                                            </textarea>
                                            <div class="form-text text-danger"><?= form_error('deskripsi'); ?></div>
                                        </div>
                                        <!-- <h5>Foto</h5>
                                        <input type="file" id="gambar" name="gambar"> -->

                                        <button type="submit" name="submit" class="btn btn-success">Update</button>
                                        <button type="reset" class="btn btn-default">Reset Button</button>
                                    </form>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>

        <?php $this->load->view('template/footer_admin'); ?>

        <!-- Page-Level Demo Scripts - Tables - Use for reference -->




