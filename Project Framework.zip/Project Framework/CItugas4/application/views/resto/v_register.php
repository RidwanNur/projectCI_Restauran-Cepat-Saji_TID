<?php defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>

<head>
  <meta charset="UTF-8">
  <title>
    Pendaftaran Akun | Tutorial Simple Login Register CodeIgniter @ http://recodeku.blogspot.com
  </title>


  <link href="<?php echo base_url('assets/css/style.css') ?>" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
  <link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>
</head>

<body>



  <?php echo form_open('register'); ?>

  <div class="container mt-5 mb-5">

    <div class="row d-flex align-items-center justify-content-center">
      <div class="col-md-6">
        <center>
          <h2>Pendaftaran Akun</h2>
        </center>
        <div class="card px-5 py-5"> <span class="circle"><i class="fa fa-check"></i></span>
          <h5 class="mt-3">Silahkan Lakukan Pendaftaran</h5>
          <div class="form-input"> <i class="fa fa-envelope"></i>
            <input type="text" class="form-control" name="name" value="<?php echo set_value('name'); ?>" placeholder="Nama">
            <?php echo form_error('name'); ?> <br>
          </div>
          <div class="form-input"> <i class="fa fa-user"></i>
            <input type="text" class="form-control" name="username" value="<?php echo set_value('username'); ?>" placeholder="User name">
            <?php echo form_error('username'); ?>
          </div><br>
          <div class="form-input"> <i class="fa fa-user"></i>
            <input type="text" class="form-control" name="email" value="<?php echo set_value('email'); ?>" placeholder="Email">
            <?php echo form_error('email'); ?>
          </div><br>
          <div class="form-input"> <i class="fa fa-lock"></i>
            <input type="password" class="form-control" name="password" value="<?php echo set_value('password'); ?>" placeholder="Password">
            <?php echo form_error('password'); ?>
          </div><br>
          <div class="form-input"> <i class="fa fa-lock"></i>
            <input type="password" class="form-control" name="password_conf" value="<?php echo set_value('password_conf'); ?>" placeholder="Konfirmasi Password">
            <?php echo form_error('password_conf'); ?>
          </div><br>
          <div class="form-check">
            <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked">
            <label class="form-check-label" for="flexCheckChecked"> I agree all the statements </label>
          </div>
          <button class="btn btn-primary mt-4 signup" type="submit" name="btnSubmit" value="Daftar">Daftar</button>
          <div class="text-center mt-4"> <span> Kembali ke beranda, Silakan klik</span> <?php echo anchor(base_url(). 'beranda', 'di sini..'); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>

</html>