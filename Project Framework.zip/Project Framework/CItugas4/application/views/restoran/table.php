<?php $this->load->view('template/header'); ?>
<title>Tabel</title>

<body>

    <div id="wrapper">

        <?php $this->load->view('template/navbar') ?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Tables</h1>
                    
                        <a class="btn btn-primary" data-toggle="modal" data-target="#formModal"><i class="fa fa-plus fa-fw"></i> Tambah Data</a>
                    
                </div>

                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            DataTables Advanced Tables
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>Kode</th>
                                        <th>Nama</th>
                                        <th>Kategori</th>
                                        <th>Harga</th>
                                        <th>Status</th>
                                        <th>Deskripsi</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php
                                    foreach ($query->result_array() as $res) {
                                        echo "<tr>";
                                        echo "<td>" . $res['kode'] . "</td>";
                                        echo "<td>" . $res['nama'] . "</td>";
                                        echo "<td>" . $res['kategori'] . "</td>";
                                        echo "<td>" . $res['harga'] . "</td>";
                                        echo "<td>" . $res['status'] . "</td>";
                                        echo "<td>" . $res['deskripsi'] . "</td>";

                                    ?>


                                        <td>
                                            <div class="btn-group">
                                                <div class="col-md-4">
                                                    <a class="btn btn-success " href="<?php echo base_url(); ?>restoran/edit/<?php echo $res['kode']; ?>"><i class="fa fa-edit fa-fw"></i></a>
                                                </div>
                                                <div class="col-md-4">
                                                    <a class="btn btn-danger" href="<?php echo base_url(); ?>restoran/deleteForm/<?php echo $res['kode']; ?>" onClick="return confirm('Are you sure you want to delete?');"><i class="fa fa-trash fa-fw"></i></a>
                                                </div>
                                            </div>
                                        </td>


                                    <?php }
                                    ?>
                                    </tr>
                                </tbody>
                            </table>
                            <!-- /.table-responsive -->

                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <?php $this->load->view('template/footer_admin'); ?>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
        $(document).ready(function() {
            $('#dataTables-example').DataTable({
                responsive: true
            });
        });
    </script>

    <!-- Modal -->
    <div class="modal fade" id="formModal" tabindex="-1" role="dialog" aria-labelledby="formModal" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title" id="formModalLabel">Tambah Data</h2>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">



                    <?php echo form_open_multipart('restoran/inputForm'); ?>


                    <?php if ($this->session->flashdata()) : ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            Data Restoran<strong>Berhasil!</strong> <?= $this->session->flashdata(); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>



                    <h5>Kode</h5>
                    <!-- <input type="text" name="kode" size="50" /> -->
                    <div class="form-group">
                        <?php
                        $code = array(
                            'name'          => 'kode',
                            'id'            => 'kode',
                            'class'            => 'form-control', 'outline-danger',


                        );

                        echo form_input($code) ?>
                    </div>
                    <div class="form-text text-danger"><?= form_error('kode'); ?></div>


                    <h5>Nama</h5>
                    <div class="form-group">
                        <?php

                        $name = array(
                            'name'          => 'nama',
                            'id'            => 'nama',
                            'class'            => 'form-control'

                        );

                        echo form_input($name) ?>
                        <div class="form-text text-danger"><?= form_error('nama'); ?></div>
                    </div>
                    <h5>Kategori</h5>
                    <div class="form-group">
                        <?php

                        $drop = array(
                            'name'          => 'kategori',
                            'id'            => 'kategori',
                            'class'            => 'form-control'
                        );

                        foreach ($query->result_array() as $row) {
                            $kategori[$row['id_kategori']] = $row['nama_kategori'];
                        }

                        $val = set_value('kategori');
                        echo form_dropdown('kategori', $kategori, $val, $drop);

                        ?>
                        <div class="form-text text-danger"><?= form_error('kategori'); ?></div>
                        <!-- <select name="kategori" id="kategori">
                        <option value="Makanan">Makanan</option>
                        <option value="Minuman">Minuman</option>
                        <option value="Lainnya">Lainnya</option>
                        </select> -->
                    </div>
                    <h5>Harga</h5>
                    <div class="form-group">
                        <?php

                        $price = array(
                            'name'          => 'harga',
                            'id'            => 'harga',
                            'class'            => 'form-control',
                            'style'         => 'width:40%'
                        );

                        echo form_input($price) ?>
                        <div class="form-text text-danger"><?= form_error('harga'); ?></div>
                    </div>
                    
                    <h5>Status</h5>
                    <div class="form-group">
                        <?php

                        $clasrad = array(
                            'class'         => 'form-check-input'
                        );


                        if (set_value('status') == 'Tersedia') {
                            $stat = TRUE;
                        } else {
                            $stat = FALSE;
                        }
                        echo form_radio('status', 'Tersedia', $stat, $clasrad);
                        echo form_label('Tersedia', 'status') . '<br>';
                        if (set_value('status') == 'Tidak Tersedia') {
                            $stat = TRUE;
                        } else {
                            $stat = FALSE;
                        }
                        echo form_radio('status', 'Tidak Tersedia', $stat, $clasrad);
                        echo form_label('Tidak Tersedia', 'status') . '<br>';
                        ?>

                        <div class="form-text text-danger"><?= form_error('status'); ?></div>
                    </div>
                    
                    <h5>Deskripsi</h5>
                    <div class="form-group">
                        <?php
                        $settextarea = array(
                            'name' => 'deskripsi',
                            'rows' => '4',
                            'cols' => '50',
                            'class'            => 'form-control'
                        );
                        echo form_textarea($settextarea) ?>
                        <div class="form-text text-danger"><?= form_error('deskripsi'); ?></div>
                    </div>


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" name="submit" class="btn btn-primary">Tambah data</button>
                    </form>
                </div>
            </div>
        </div>
    </div>