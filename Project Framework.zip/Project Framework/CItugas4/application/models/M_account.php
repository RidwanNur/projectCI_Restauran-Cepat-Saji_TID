<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_account extends CI_Model{

    function daftar($data)
    {
         $this->db->insert('users',$data);
    }

    public function get_all()
    {
        $query = $this->db->get('users');
        return $query;
    }

    public function getById($id_user)
    {
        return $this->db->get_where('users', ["id_user" => $id_user])->row_array();
    }

}