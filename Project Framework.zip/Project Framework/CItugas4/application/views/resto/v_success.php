<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>  
<head>
<meta charset="UTF-8">
<title>
  Notifikasi 
</title>
<link href="<?php echo base_url('assets/css/style.css') ?>" rel="stylesheet">
</head>
<body>
<div class="container">
	<div class="box">
	<h3><?php echo $message; ?></h3>
  <p><?php echo anchor('beranda','Kembali ke beranda'); ?></p>
	</div>
</div>

</body>
</html>