<?php $this->load->view('template/header'); ?> 

<!-- ======= Footer ======= -->
<link href="<?php echo base_url('assets/css/style.css') ?>" rel="stylesheet">  

 <!-- ======= Footer ======= -->
 <footer id="footer">
    <div class="container">
      <h3>Delicious</h3>
      <p>Kunjungi Sosial Media Kami Untuk Melihat Promo Menarik dan Info Terbaru tentang Restoran Kami.</p>
      
      <div class="social-links">
        <a class="btn btn-social-icon btn-twitter"><i class="fa fa-twitter"></i></a>
        <a class="btn btn-social-icon btn-facebook"><i class="fa fa-facebook"></i></a>
        <a class="btn btn-social-icon btn-instagram"><i class="fa fa-instagram"></i></a>
        <a class="btn btn-social-icon btn-linkedin"><i class="fa fa-skype"></i></a>
        <a class="btn btn-social-icon btn-linkedin"><i class="fa fa-linkedin"></i></a>
      </div>
      <div class="copyright">
        &copy; Copyright <strong><span>Delicious</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
      
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>
    </div>
  </footer><!-- End Footer -->

