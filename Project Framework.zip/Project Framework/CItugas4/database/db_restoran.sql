-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 20, 2021 at 06:15 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_restoran`
--

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` varchar(50) NOT NULL,
  `nama_kategori` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
('Lain', 'Lainnya'),
('Mak', 'Makanan'),
('Min', 'Minuman');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_restoran`
--

CREATE TABLE `tbl_restoran` (
  `kode` varchar(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `kategori` varchar(250) NOT NULL,
  `harga` int(11) NOT NULL,
  `status` varchar(20) NOT NULL,
  `deskripsi` varchar(500) NOT NULL,
  `img` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_restoran`
--

INSERT INTO `tbl_restoran` (`kode`, `nama`, `kategori`, `harga`, `status`, `deskripsi`, `img`) VALUES
('A01', 'Mie Ayam Pangsit', 'Mak', 15000, 'Tersedia', 'Mie ayam dengan isian ayam dan jamur dengan tambahan pangsit \r\n \r\n \r\n', ''),
('A04', 'Mie Goreng', 'Mak', 23000, 'Tersedia', 'jf rgsr edrf rtg ', ''),
('A05', 'Nasi Goreng', 'Mak', 20000, 'Tersedia', 'erthbrtbf evbed', ''),
('I01', 'Milkshake Coklat', 'Min', 15000, 'Tersedia', 'ljjbkscbzsx', ''),
('I02', 'Jus semangka', 'Lain', 8000, 'Tersedia', 'asddacs sdxazaxzx dfcasxcz\r\n', ''),
('L01', 'Kentang goreng', 'Lain', 8000, 'Tersedia', 'kentang goreng \r\n \r\n \r\n \r\n', ''),
('L02', 'Sosis Goreng', 'Lain', 6000, 'Tersedia', 'fyukd fsbsv \r\n \r\n', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `nama`, `email`, `username`, `password`) VALUES
(1, 'arsananeon', 'arsananeon@gmail.com', 'neon', '86a0dd36faa1276767998820fbc53732'),
(10, 'Jaehyun Jeong', 'jaejae@email.com', 'JeffreyJung', 'a5759ca3e37c6e6630df12034e06cf05'),
(11, 'Liam Johnson', 'johnliam12@email.com', 'Liam', 'fad0ddeaf893ff0497d5da12db264526'),
(12, 'Joan Lee', 'lee_joan@email.com', 'Joan', 'dd54d716aaa387acf14d145d0c89d106'),
(13, 'Logan Lee', 'loganlee@email.com', 'Logan', '3447adfd742cdfb9048a3b29baf1ae7d'),
(14, 'Denise Nirmala', 'denirmala@email.com', 'Denise', '968c58d88d981b4ee15e2c8cb1fab06d'),
(16, 'Yumna Amalia', 'yumnaamalia@email.com', 'yumna', '81dc9bdb52d04dc20036dbd8313ed055');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `tbl_restoran`
--
ALTER TABLE `tbl_restoran`
  ADD PRIMARY KEY (`kode`),
  ADD KEY `kategori` (`kategori`(50)),
  ADD KEY `kategori_2` (`kategori`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_restoran`
--
ALTER TABLE `tbl_restoran`
  ADD CONSTRAINT `tbl_restoran_ibfk_1` FOREIGN KEY (`kategori`) REFERENCES `kategori` (`id_kategori`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
