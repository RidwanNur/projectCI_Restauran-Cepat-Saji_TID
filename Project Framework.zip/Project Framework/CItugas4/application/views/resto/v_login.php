<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>

<head>
  <meta charset="UTF-8">
  <link href="<?php echo base_url('assets/css/login.css') ?>" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Karla:400,700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.materialdesignicons.com/4.8.95/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <title>
    Halaman Login
  </title>
</head>

<body>
  <?php
  // Cetak jika ada notifikasi
  if ($this->session->flashdata('sukses')) {
    echo '<p class="warning" style="margin: 10px 20px;">' . $this->session->flashdata('sukses') . '</p>';
  }
  ?>
  <?php echo form_open('login'); ?>
  <main>
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-6 login-section-wrapper">
          <div class="brand-wrapper">
            <img src="assets/images/resto.jpg" alt="logo" class="logo">
          </div>
          <div class="login-wrapper my-auto">
            <h1 class="login-title">Log in</h1>
            <form action="#!">
              <div class="form-group">
              <label for="password">Username</label>
              <input type="text" class="form-control" name="username" id="username" placeholder="Masukkan Username" value="<?php echo set_value('username'); ?>">
              <p> <?php echo form_error('username'); ?> </p>
              </div>
              <div class="form-group">
              <label for="password">Password</label>
              <input type="password" class="form-control" name="password" id="password" placeholder="Masukkan Password" value="<?php echo set_value('password'); ?>">
              <p> <?php echo form_error('password'); ?> </p>
              </div>
              <input name="submit" type="submit" id="login" class="btn btn-block login-btn"  value="Login">
            </form>
            <a href="#!" class="forgot-password-link">Forgot password?</a><br>
            Kembali Ke <a href="<?php base_url() ?>beranda"  >Beranda</a>
            <p class="login-wrapper-footer-text">Belum Punya Akun? <a href="<?php base_url() ?>register" class="text-reset">Daftar Disini</a></p>
          </div>
        </div>
        <div class="col-sm-6 px-0 d-none d-sm-block">
          <img src="assets/images/bg4.jpg" alt="login image" class="login-img">
        </div>
      </div>
    </div>
  </main>
  
  <?php echo form_close(); ?>
  <footer></footer>

</body>

</html>