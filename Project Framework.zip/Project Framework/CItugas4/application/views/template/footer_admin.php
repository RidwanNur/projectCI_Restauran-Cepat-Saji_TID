<!-- jQuery -->
<script src="<?php echo base_url(); ?>assets2/vendor/jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url(); ?>assets2/vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url(); ?>assets2/vendor/metisMenu/metisMenu.min.js"></script>

<!-- Morris Charts JavaScript -->
<script src="<?php echo base_url(); ?>assets2/vendor/raphael/raphael.min.js"></script>
<script src="<?php echo base_url(); ?>assets2/vendor/morrisjs/morris.min.js"></script>
<script src="<?php echo base_url(); ?>assets2/data/morris-data.js"></script>

<!-- DataTables JavaScript -->
<script src="<?php echo base_url(); ?>assets2/vendor/datatables/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets2/vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets2/vendor/datatables-responsive/dataTables.responsive.js"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url(); ?>assets2/dist/js/sb-admin-2.js"></script>

</body>

</html>